# Relayr_Sample_Project

Sample project

Requirements :
1. Install Python 3.6 and above
2. Install Selenium (pip install selenium)
3. Install behave (pip install behave)
4. Chrome Webdriver for Selenium
5. Add the chrome webdriver path in Environmental Variables