from typing import Tuple

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from browser import Browser

class HomePageLocator(object):
    # Home Page Locators

    SEARCH_FIELD = (By.XPATH, "//input[@name='q']")
    CLICK_FIELD = (By.XPATH, "//h3[contains(text(),'Relayr - Industrial IoT Powerhouse')]")


class HomePage(Browser):
    # Home Page Actions

    def fill(self, text, *locator):
        self.driver.find_element(*locator).send_keys(text)
        self.driver.find_element(*locator).send_keys(Keys.RETURN)

    def click_element(self, *locator):
        self.driver.find_element(*HomePageLocator.SEARCH_FIELD).click()

    def navigate(self, address):
        self.driver.get(address)

    def get_page_title(self,*locator):
        self.driver.find_element(*HomePageLocator.CLICK_FIELD).click()

    def search(self, search_term):
        self.fill(search_term, *HomePageLocator.SEARCH_FIELD)