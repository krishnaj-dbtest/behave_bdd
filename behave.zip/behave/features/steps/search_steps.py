from nose.tools import assert_equal, assert_true
from behave import *
from selenium.webdriver.common.by import By

@given('Navigate to the Google Home page')
def step_impl(context):
    context.home_page.navigate("https://google.com")

@when('Search for "{search_term}"')
def step_impl(context, search_term):
    context.home_page.search(search_term)

@then('Taken to the Google Search Results page "{search_term}"')
def step_impl(context,search_term):
    assert(context.home_page.click_element(), search_term), True
